module.exports = locations => {
  return `Nucamp offers classes in ${locations.join(', ')}.`;
};