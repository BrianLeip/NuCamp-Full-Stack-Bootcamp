const express = require('express');
const locationRouter = express.Router();

const locations = ['Tacoma', 'Marysville', 'Seattle', 'Spokane', 'Bellingham'];

locationRouter.route('/locations')
.all((req, res, next) => {
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/plain");
  next();
})
.get((req, res) => {
  res.send(locations);
  res.end;
})
.post((req, res) => {
  if(req) {
    locations.push(req.body.location);
    res.end(`Successfully added location: ${req.body.location}`);
  }
  else {
    res.end("Error: no location to add");
  }
})
module.exports = locationRouter;