const express = require('express');
var secretRouter = express.Router();

function auth(req, res, next) {
  console.log(req.headers);
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    const err = new Error('You are not authenticated!');
    res.setHeader('WWW-Authenticate', 'Basic');
    err.status = 401;
    return next(err);
  }

  const auth = Buffer.from(authHeader.split(' ')[1], 'base64').toString().split(':'); // convert authHeader username:password into an array
  const user = auth[0];
  const pass = auth[1];
  if (user.toLowerCase() === 'jbond' && pass === 'AstonMartin007') {
    return next();  // authorized
  } else {
    const err = new Error('You are not authenticated!');
    res.setHeader('WWW-Authenticate', 'Basic');
    err.status = 401;
    return next(err);
  }
}

secretRouter.use(auth);

secretRouter.route('/')
.get((req, res) => {
  res.end('RIP Sean Connery');
});

module.exports = secretRouter;